# Canadian Breast Cancer Analysis

Open **Canadian Breast Cancer Analysis - Four Pages.pbip** in Power BI Desktop. Select **Home → Refresh** on first open to process the embedded CSV snapshots. This project is a private research report.

## Audit and provenance

| Page | Displayed values | Source |
|---|---|---|
| Executive Overview | 569 biopsy cases, 357 benign, 212 malignant, 30 features, 7 components, 91.0% retained variance | Wisconsin Diagnostic Breast Cancer benchmark, `data/cases.csv` and `data/variance.csv` |
| Executive Overview | Weighted logistic and weighted RBF SVC on 7 PCs tied: 97.18% mean malignant recall each, 6 of 212 malignant cases missed; mean ROC AUC 99.41% and 99.53% | Five held-out folds, `data/folds.csv` and `data/validation_summary.json` |
| PCA and Validation | PC1 and PC2 score for each case, 63.24% at 2 components, 91.01% at 7, 95.16% at 10 | Verified case payload and descriptive PCA, `data/cases.csv` and `data/variance.csv` |
| PCA and Validation | Weighted logistic 30 features · 96.70%, 99.37%, 7 missed. Unweighted logistic 7 PCs · 94.84%, 99.46%, 11 missed. Weighted logistic 7 PCs · 97.18%, 99.41%, 6 missed. Weighted RBF SVC 7 PCs · 97.18%, 99.53%, 6 missed. | Recomputed five-fold run, `data/folds.csv`. Within-fold recall is derived from detected and missed counts. ROC AUC is estimated from ranked decision scores. |
| Biopsy Findings | Six medians for each diagnosis group | Original case-level morphology, `data/cases.csv`. Measures use MEDIAN in the current diagnosis context. |
| Canadian Context | Annual age-standardized rates, 1992–2023, and province rates with published 95% intervals, 2023 | Statistics Canada 13-10-0747-01. Every plotted rate and interval is listed in `data/incidence_trend.csv` and `data/incidence_province.csv`. |
| Canadian Context | 2017 stage counts 35, 8020, 7085, 2120, 1040, 935 and 215 in extract order | Statistics Canada 13-10-0761-01, `data/stage.csv`, Canada excluding Quebec |
| Canadian Context | Stage I 99.8%, II 91.9%, III 74.0%, IV 23.2% | Statistics Canada Health Reports 82-003-X, Table 1, `data/survival.csv`, 2010–2017, women aged 15–99, Canada excluding Quebec |

The incidence trend uses Canada excluding Nova Scotia for every year from 1992 to 2023, so the series never changes coverage. Nova Scotia has no reported 2023 provincial rate in the extract. The other nine provinces are shown. Counts are randomly rounded to multiples of five at source. Age-standardized incidence is expressed per 100,000 using the 2021 Census population structure. Canadian population tables are independent of the case model.

[Incidence, Table 13-10-0747-01](https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1310074701) · [Stage, Table 13-10-0761-01](https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1310076101) · [Stage-specific survival, Health Reports](https://www150.statcan.gc.ca/n1/pub/82-003-x/2023001/article/00001-eng.htm) · [Wisconsin dataset](https://archive.ics.uci.edu/dataset/17/breast-cancer-wisconsin-diagnostic)

## Removal and reconciliation

- The backup's case table held simulated cohort, simulated age band, consult days and an access score. The age-band and cohort dimensions copied distinct simulated keys. The notebook created seeded demographic groups and generated consultation and access values with cohort-dependent offsets and noise.
- The rebuilt model excludes these fields, dimensions, relationships, related filters, wait and access measures, threshold calculations, and both pages that depended on them. It also removes the unsupported capacity scenario, experimental grand-total aggregation, and stand-alone holdout page.
- The notebook's 98.44% is a single split result. The headline uses cross-validation. The two weighted seven-component models tie on recall and misses, and the report presents them as tied. Their mean ROC AUC differs by 0.12 points, within fold-to-fold variation. The four-model comparison reuses the same folds and is an internal comparison.
- The full-feature logistic reference is class-weighted in the reproducible pipeline. The report labels it accordingly. The single holdout is omitted from the report to keep the evaluation scope consistent.
- Stage-specific survival is sourced from the verified Health Reports table. The stage extract and survival period differ from the current incidence release. Each visual displays its own reporting period.
- Scatter plots use adjacent, labelled benign and malignant panels as a second encoding. Confidence bounds on the province chart are supplied as tooltip fields.

## Rebuild

Download the official full-table archives `13100747-eng.zip` and `13100761-eng.zip`. Run `python tools/extract_statcan.py path/to/13100747-eng.zip path/to/13100761-eng.zip`. The four stage-specific survival values are transcribed from the cited published table. The Power BI project files are the source of truth. Power Query reads byte-identical snapshots of the committed CSVs, embedded for portability. After replacing an extract, update the matching table's embedded snapshot and refresh in Power BI Desktop.
## Verification status

- Parsed the saved report JSON and verified four pages, three navigation targets per page, and alternative text on every visual.
- Searched report JSON, TMDL and data extracts for the removed demographic and access fields. The audit notes document the removed material.
- Simulated full-severity colour deficiencies for the selected series. Malignant/benign render as #4B505C/#5970A1 for protanopia, #767057/#4A659E for deuteranopia, and #D40039/#007B80 for tritanopia. Separate labelled scatter panels provide the second encoding.
- The official stage-specific survival estimates come from the Health Reports stage table. Table 13-10-0160-01 provides net survival by cancer site and sex without a stage breakdown.
- Opened, refreshed and saved in Power BI Desktop on 2026-11-16. All four pages render. A duplicate measure name that blocked loading was fixed (the provincial measure is now `Provincial rate shown`). Pages were exported to PDF and checked visually.
