import csv
import io
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
PROVINCES = ("Alberta", "British Columbia", "Manitoba", "New Brunswick",
             "Newfoundland and Labrador", "Nova Scotia", "Ontario",
             "Prince Edward Island", "Quebec", "Saskatchewan")

def write(name, headers, records):
    with (DATA / (name + ".csv")).open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(records)

def breast(archive, number):
    with zipfile.ZipFile(archive) as zip_file, io.TextIOWrapper(
        zip_file.open(number + ".csv"), encoding="utf-8-sig"
    ) as stream:
        for row in csv.DictReader(stream):
            if (row["Sex"] == "Females"
                and row["Primary types of cancer (ICD-O-3)"] == "Breast [C50.0-C50.9]"
                and row["VALUE"]):
                yield row

def extract(incidence, stage):
    indexed = defaultdict(dict)
    for row in breast(incidence, "13100747"):
        indexed[int(row["REF_DATE"]), row["GEO"]][row["Characteristics"]] = row["VALUE"]
    rate = "Cancer incidence rate"
    years = sorted({year for (year, geo), vals in indexed.items() if geo.startswith("Canada") and rate in vals})
    trend = []
    for year in years:
        # One geography for every year, so the line never changes coverage mid-series.
        # Nova Scotia has no reported rate after 2019, so Canada excluding Nova Scotia is used throughout.
        geo = "Canada (excluding Nova Scotia)"
        vals = indexed[year, geo]
        trend.append((year, geo, vals[rate]))
    assert years == list(range(1992, max(years)+1))
    write("incidence_trend", ("Year","Coverage","Rate per 100,000"), trend)
    latest = max(years)
    by_province = []
    for geo in PROVINCES:
        vals = indexed.get((latest, geo), {})
        if rate in vals:
            by_province.append((latest, geo, vals[rate], vals["Low 95% confidence interval, cancer incidence rate"],
                                vals["High 95% confidence interval, cancer incidence rate"]))
    write("incidence_province", ("Year","Province","Rate per 100,000","Lower 95% CI","Upper 95% CI"), by_province)
    stage_rows = []
    for row in breast(stage, "13100761"):
        name = row["Stage at diagnosis "].replace(" (Collaborative Stage)", "")
        if (row["GEO"] == "Canada excluding Quebec" and row["Age group"] == "Total, all ages"
            and row["Characteristics"].strip() == "Total number of cancer cases"
            and not name.startswith("All stages")):
            stage_rows.append((int(row["REF_DATE"]),name,row["VALUE"]))
    latest_stage = max(r[0] for r in stage_rows)
    write("stage", ("Year","Stage","New cases"), sorted(r for r in stage_rows if r[0]==latest_stage))
    # Published estimates transcribed from Statistics Canada Health Reports, 82-003-X, 2023, Table 1.
    write("survival", ("Stage","Five-year net survival"), zip(("Stage I","Stage II","Stage III","Stage IV"), ("0.998","0.919","0.740","0.232")))

if __name__ == "__main__":
    extract(*sys.argv[1:])
